"""Generate table of contents for pdf based on a recipe file"""

__version__ = '1.3.3'
