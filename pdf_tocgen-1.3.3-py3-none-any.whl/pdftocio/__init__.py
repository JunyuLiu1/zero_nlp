"""Manipulating the table of contents of a pdf"""

__version__ = '1.3.3'
